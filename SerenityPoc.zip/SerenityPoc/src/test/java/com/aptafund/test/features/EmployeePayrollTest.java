package com.aptafund.test.features;

import com.aptafund.test.steps.payroll_steps.ManagePayrollSteps;
import net.serenitybdd.junit.runners.SerenityRunner;
import net.thucydides.core.annotations.Managed;
import net.thucydides.core.annotations.Steps;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.openqa.selenium.WebDriver;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Created by omii on 8/17/2016.
 */

@RunWith(SerenityRunner.class)
public class EmployeePayrollTest {
    private static final Logger logger = LoggerFactory.getLogger(EmployeePayrollTest.class);

    @Managed
    WebDriver driver;


    @Steps
    ManagePayrollSteps managePayrollSteps;

    @Ignore
    @Test
    public void verifyLoginPageIsAppearing() {
        managePayrollSteps.navigateToLoginPage();

    }

    @Test
    public void VerifyLoginIntoSite(){

        managePayrollSteps.navigateToLoginPage();
        managePayrollSteps.loginIntoSite();

    }

    @Ignore
    @Test
    public void test1(){}

    @Ignore
    @Test
    public void test2(){}


}