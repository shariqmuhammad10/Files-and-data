package com.aptafund.test.pages.common;

import com.aptafund.test.actions.WaitActions;
import net.serenitybdd.core.pages.WebElementFacade;
import org.openqa.selenium.support.FindBy;

/**
 * Created by omii on 8/17/2016.
 */
public class AptaHomePage extends WaitActions {

    @FindBy (id = "btnLogout")
    private WebElementFacade homePageTitle;


//    @FindBy (id = "btnLogout")
//    private WebElementFacade homePageTitle;
//
//    @FindBy (id = "btnLogout")
//    private WebElementFacade homePageTitle;
//
//    @FindBy (id = "btnLogout")
//    private WebElementFacade homePageTitle;


    public boolean homePageIsDisplayed(){
        return homePageTitle.isDisplayed();

    }










}
