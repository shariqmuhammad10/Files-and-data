package com.aptafund.test.actions;

import net.thucydides.core.pages.PageObject;

/**
 * Created by zuhair.mukry on 2/23/2016.
 */
public class AbstractPageAction extends PageObject {
}
