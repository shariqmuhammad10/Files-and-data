package com.aptafund.test.pages.common;

import com.aptafund.test.actions.WaitActions;
import net.serenitybdd.core.pages.WebElementFacade;
import org.openqa.selenium.support.FindBy;

/**
 * Created by omii on 8/17/2016.
 */

//@DefaultUrl("")
public class AptaLoginPage extends WaitActions {


    @FindBy(id = "login")
    private WebElementFacade pageTitle;

    @FindBy(id = "loginName")
    private WebElementFacade loginName;

    @FindBy(id = "Password")
    private WebElementFacade password;

    @FindBy(css = ".login-button")
    private WebElementFacade loginButton;


    public void loginIntoApta(String userName, String passwordId) {
        waitUntilLoaded(loginName);
        loginName.clear();
        loginName.sendKeys(userName);

        password.clear();
        password.sendKeys(passwordId);

        waitUntilLoaded(loginButton);
        loginButton.click();

    }

    public boolean verifyPageIsOpen() {
        return pageTitle.isDisplayed();

    }
}
